Ejecutar solar_system.py
Apretar espacio para ver los dibujos en líneas
Apretar escape para cerrar ventana