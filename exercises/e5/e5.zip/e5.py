""" P3 [Drive simulator] """

import glfw
import OpenGL.GL.shaders
import numpy as np
import grafica.basic_shapes as bs
import grafica.easy_shaders as es
import grafica.transformations as tr
import grafica.performance_monitor as pm
import grafica.scene_graph as sg
from shapes import *
from model import *


# We will use 32 bits data, so an integer has 4 bytes
# 1 byte = 8 bits
SIZE_IN_BYTES = 4


# Clase controlador con variables para manejar el estado de ciertos botones
class Controller:
    def __init__(self):
        self.fillPolygon = True
        self.is_w_pressed = False
        self.is_s_pressed = False
        self.is_a_pressed = False
        self.is_d_pressed = False


# we will use the global controller as communication with the callback function
controller = Controller()

# This function will be executed whenever a key is pressed or released
def on_key(window, key, scancode, action, mods):
    
    global controller
    
    # Caso de detectar la tecla [W], actualiza estado de variable
    if key == glfw.KEY_W:
        if action ==glfw.PRESS:
            controller.is_w_pressed = True
        elif action == glfw.RELEASE:
            controller.is_w_pressed = False

    # Caso de detectar la tecla [S], actualiza estado de variable
    if key == glfw.KEY_S:
        if action ==glfw.PRESS:
            controller.is_s_pressed = True
        elif action == glfw.RELEASE:
            controller.is_s_pressed = False

    # Caso de detectar la tecla [A], actualiza estado de variable
    if key == glfw.KEY_A:
        if action ==glfw.PRESS:
            controller.is_a_pressed = True
        elif action == glfw.RELEASE:
            controller.is_a_pressed = False

    # Caso de detectar la tecla [D], actualiza estado de variable
    if key == glfw.KEY_D:
        if action ==glfw.PRESS:
            controller.is_d_pressed = True
        elif action == glfw.RELEASE:
            controller.is_d_pressed = False

    # Caso de detecar la barra espaciadora, se cambia el metodo de dibujo
    if key == glfw.KEY_SPACE and action ==glfw.PRESS:
        controller.fillPolygon = not controller.fillPolygon

    # Caso en que se cierra la ventana
    elif key == glfw.KEY_ESCAPE and action ==glfw.PRESS:
        glfw.set_window_should_close(window, True)



if __name__ == "__main__":

    # Initialize glfw
    if not glfw.init():
        glfw.set_window_should_close(window, True)

    # Creating a glfw window
    width = 800
    height = 800
    title = "P3 - Drive simulator"
    window = glfw.create_window(width, height, title, None, None)

    if not window:
        glfw.terminate()
        glfw.set_window_should_close(window, True)

    glfw.make_context_current(window)

    # Connecting the callback function 'on_key' to handle keyboard events
    glfw.set_key_callback(window, on_key)

    # Pipeline para dibujar shapes con colores interpolados
    pipeline = es.SimpleTransformShaderProgram()
    # Pipeline para dibujar shapes con texturas
    tex_pipeline = es.SimpleTextureTransformShaderProgram()

    # Setting up the clear screen color
    glClearColor(0.15, 0.15, 0.15, 1.0)

    # Enabling transparencies
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

    # Grafo de escena del auto
    car = createCar(pipeline) 
    # Grafo de escena del background
    mainScene = createScene(pipeline)
    # Se añade el auto a la escena principal
    mainScene.childs += [car]

    # Se instancia el modelo del auto
    player = Player(0.3)
    # Se indican las referencias del nodo y el controller al modelo
    player.set_model(car)
    player.set_controller(controller)

    # Shape con textura de la carga
    garbage = createTextureGPUShape(bs.createTextureQuad(1,1), tex_pipeline, "sprites/bag.png")

    # Se crean dos nodos de carga
    garbage1Node = sg.SceneGraphNode("garbage1")
    garbage1Node.childs = [garbage]

    garbage2Node = sg.SceneGraphNode("garbage2")
    garbage2Node.childs = [garbage]

    # Se crean el grafo de escena con textura y se agregan las cargas
    tex_scene = sg.SceneGraphNode("textureScene")
    tex_scene.childs = [garbage1Node, garbage2Node]

    # Se crean los modelos de la carga, se indican su nodo y se actualiza la posicion fija
    carga1 = Carga(0.2, -0.55, 0.1)
    carga1.set_model(garbage1Node)
    carga1.update()

    carga2 = Carga(0.7, -0.75, 0.1)
    carga2.set_model(garbage2Node)
    carga2.update()

    # Lista con todas las cargas
    cargas = [carga1, carga2]

    perfMonitor = pm.PerformanceMonitor(glfw.get_time(), 0.5)
    # glfw will swap buffers as soon as possible
    glfw.swap_interval(0)
    t0 = glfw.get_time()

    # Application loop
    while not glfw.window_should_close(window):
        # Variables del tiempo
        t1 = glfw.get_time()
        delta = t1 -t0
        t0 = t1

        # Measuring performance
        perfMonitor.update(glfw.get_time())
        glfw.set_window_title(window, title + str(perfMonitor))
        # Using GLFW to check for input events
        glfw.poll_events()

        # Filling or not the shapes depending on the controller state
        if (controller.fillPolygon):
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
        else:
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)

        # Clearing the screen
        glClear(GL_COLOR_BUFFER_BIT)

        # Se llama al metodo del player para detectar colisiones
        player.collision(cargas)
        # Se llama al metodo del player para actualizar su posicion
        player.update(delta)

        # Se llama al metodo de cada carga para actualizar su posición
        cargas[0].pos[0]=-t0%4 -2
        if (cargas[0].pos[0]<=-1):
            cargas[0].pos[1]=-(np.random.randint(45, 80))/100
        cargas[0].update()

        cargas[1].pos[0]=-t0%6.3 -2
        if (cargas[1].pos[0]<=-1):
            cargas[1].pos[1]=-(np.random.randint(45, 80))/100
        cargas[1].update()

        # Se crea el movimiento de giro del rotor
        rotor = sg.findNode(mainScene, "rtRotor")
        rotor.transform = tr.rotationZ(t1)

        # Se crea el movimiento de montañas
        montañas = sg.findNode(mainScene, "mountains")
        montañas.transform = tr.matmul([tr.translate(-t0%2, -0.3, 0), tr.scale(1, 1, 1)])

        montañas2 = sg.findNode(mainScene, "mountains2")
        montañas2.transform = tr.matmul([tr.translate(-t0%2 -2, -0.3, 0), tr.scale(1, 1, 1)])

        montañas3 = sg.findNode(mainScene, "mountains3")
        montañas3.transform = tr.matmul([tr.translate(-t0%2 -4, -0.3, 0), tr.scale(1, 1, 1)])

        # Se crea el movimiento de las torres
        torres = sg.findNode(mainScene, "windMills")
        torres.transform = tr.matmul([tr.translate(-t0%4 -2, -0.3, 0), tr.scale(1, 1, 1)])

        # Se dibuja el grafo de escena principal
        glUseProgram(pipeline.shaderProgram)
        sg.drawSceneGraphNode(mainScene, pipeline, "transform")

        # Se dibuja el grafo de escena con texturas
        glUseProgram(tex_pipeline.shaderProgram)
        sg.drawSceneGraphNode(tex_scene, tex_pipeline, "transform")

        # Once the drawing is rendered, buffers are swap so an uncomplete drawing is never seen.
        glfw.swap_buffers(window)

    # freeing GPU memory
    mainScene.clear()
    tex_scene.clear()
    
    glfw.terminate()